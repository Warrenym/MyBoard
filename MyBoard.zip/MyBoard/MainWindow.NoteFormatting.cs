﻿using MyBoard.ViewModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;

namespace MyBoard
{
    public partial class MainWindow
    {
        // The RichTextBox the formatting toolbar currently acts on — set
        // whenever a note's design panel becomes active, mirroring how
        // TextStylePicker tracks its own target
        private RichTextBox? activeFormattingTarget;

        // Called from NoteRichTextBox's own SelectionChanged (the note
        // itself, not the toolbar) — keeps toggle buttons in sync live as
        // the caret moves, not just after a click
        private void NoteRichTextBox_RefreshFormatState(RichTextBox rtb)
        {
            activeFormattingTarget = rtb;

            var selection = rtb.Selection;
            SetToggleState("BoldToggle", selection.GetPropertyValue(TextElement.FontWeightProperty) is FontWeight fw && fw == FontWeights.Bold);
            SetToggleState("ItalicToggle", selection.GetPropertyValue(TextElement.FontStyleProperty) is FontStyle fs && fs == FontStyles.Italic);
            SetToggleState("UnderlineToggle", HasDecoration(selection, TextDecorations.Underline));
            SetToggleState("StrikeToggle", HasDecoration(selection, TextDecorations.Strikethrough));
        }

        private static bool HasDecoration(TextSelection selection, TextDecorationCollection target)
        {
            var value = selection.GetPropertyValue(Inline.TextDecorationsProperty);
            return value is TextDecorationCollection decorations &&
                   decorations.Count > 0 &&
                   decorations[0].Location == target[0].Location;
        }

        // Finds the named toggle button anywhere in the current visual tree
        // and sets its checked state — the Note design panel is only ever
        // instantiated once at a time (for whichever note is selected), so
        // a simple FindName lookup from the Window is sufficient here
        private void SetToggleState(string name, bool isActive)
        {
            if (((FrameworkElement)Content).FindName(name) is ToggleButton toggle)
                toggle.IsChecked = isActive;
        }

        // Applies the clicked format to the current selection/caret using
        // WPF's built-in EditingCommands — these already handle "toggle on
        // if off, toggle off if on" correctly on their own
        private void FormatToggle_Click(object sender, RoutedEventArgs e)
        {
            if (activeFormattingTarget == null) return;
            if (sender is not ToggleButton toggle || toggle.Tag is not string format) return;

            var selection = activeFormattingTarget.Selection;
            if (selection.IsEmpty) return; // Nothing selected — nothing to format yet

            switch (format)
            {
                case "Bold":
                    bool isBold = selection.GetPropertyValue(TextElement.FontWeightProperty) is FontWeight fw && fw == FontWeights.Bold;
                    selection.ApplyPropertyValue(TextElement.FontWeightProperty, isBold ? FontWeights.Normal : FontWeights.Bold);
                    break;

                case "Italic":
                    bool isItalic = selection.GetPropertyValue(TextElement.FontStyleProperty) is FontStyle fst && fst == FontStyles.Italic;
                    selection.ApplyPropertyValue(TextElement.FontStyleProperty, isItalic ? FontStyles.Normal : FontStyles.Italic);
                    break;

                case "Underline":
                    bool hasUnderline = HasDecoration(selection, TextDecorations.Underline);
                    selection.ApplyPropertyValue(Inline.TextDecorationsProperty, hasUnderline ? null : TextDecorations.Underline);
                    break;

                case "Strikethrough":
                    ToggleStrikethrough(activeFormattingTarget);
                    break;
            }

            activeFormattingTarget.Focus();
        }

        // Strikethrough has no built-in EditingCommand, so we toggle it
        // manually on the current selection
        private void ToggleStrikethrough(RichTextBox rtb)
        {
            bool alreadyStruck = HasDecoration(rtb.Selection, TextDecorations.Strikethrough);
            rtb.Selection.ApplyPropertyValue(Inline.TextDecorationsProperty,
                alreadyStruck ? null : TextDecorations.Strikethrough);
        }
    }
}